<?php
	$servername = "localhost";
	$username = "root";
	$password = "asul_tema3";
	$database = "ASUL";

	$conn = new mysqli($servername, $username, $password, $database);
	$content = "";
	if ($conn->connect_error) {
  	  die("Connection failed: " . $conn->connect_error);
	}
	
	$query = "SELECT Model,Year,HP,Type,Color FROM cars ORDER BY Year DESC";
	$queryResult = $conn->query($query);
	while ($queryRow = $queryResult->fetch_row()) {
		$content = $content."<tr>";
		for($i = 0; $i < $queryResult->field_count; $i++){
			$content = $content."<td>$queryRow[$i]</td>";
		}
		$content = $content."</tr>";
	}
	$conn->close();
?> 

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Third Website (Website3.ro)</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-secondary p-3">
	<a class="navbar-brand" href="index.php">Website3.ro</a>
	<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	    <div class="navbar-nav">
	      <a class="nav-item nav-link" href="index.php">Utilizatori</a>
	      <a class="nav-item nav-link active" href="#">Masini</a>
	      <a class="nav-item nav-link" href="shops.php">Magazine</a>
	    </div>
	</div>
    </nav>
    <div class="m-5 d-flex justify-content-center align-items-center">
    	<table class="table table-striped">
	  <thead>
	    <tr>
	      <th scope="col">Model</th>
	      <th scope="col">Year</th>
	      <th scope="col">HP</th>
	      <th scope="col">Type</th>
	      <th scope="col">Color</th>
	    </tr>
	  </thead>
	  <tbody>
	    <?php echo $content; ?>
	  </tbody>
	</table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
