<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Second Website (Website2.ro)</title>
  </head>
  <body>
    <div class="d-flex justify-content-around p-5">
    	<form action="action_get.php" method="GET">
    	  <div class="form-group mt-2">
	    <label for="firstName">First Name</label>
	    <input required type="text" class="form-control" id="firstName" name="firstName" placeholder="Enter first name">
	  </div>
	  <div class="form-group mt-2">
	    <label for="lastName">Last Name</label>
	    <input required type="text" class="form-control" id="lastName" name="lastName" placeholder="Enter last name">
	  </div>
	  <div class="form-group mt-2">
	    <label for="emailAddress">Email Adress</label>
	    <input required type="email" class="form-control" id="emailAddress" name="emailAddress" aria-describedby="emailHelp" placeholder="Enter email address">
	  </div>
	  <div class="form-group mt-2">
	    <label for="passwordCurrent">Password</label>
	    <input required type="password" class="form-control" id="passwordCurrent" name="passwordCurrent" placeholder="Password">
	  </div>
	  <button type="submit" class="btn btn-primary mt-2">Submit GET</button>
	</form>
    	<form action="action_post.php" method="POST">
    	  <div class="form-group mt-2">
	    <label for="firstName">First Name</label>
	    <input required type="text" class="form-control" id="firstName" name="firstName" placeholder="Enter first name">
	  </div>
	  <div class="form-group mt-2">
	    <label for="lastName">Last Name</label>
	    <input required type="text" class="form-control" id="lastName" name="lastName" placeholder="Enter last name">
	  </div>
	  <div class="form-group mt-2">
	    <label for="emailAddress">Email Adress</label>
	    <input required type="email" class="form-control" id="emailAddress" name="emailAddress" aria-describedby="emailHelp" placeholder="Enter email address">
	  </div>
	  <div class="form-group mt-2">
	    <label for="passwordCurrent">Password</label>
	    <input required type="password" class="form-control" id="passwordCurrent" name="passwordCurrent" placeholder="Password">
	  </div>
	  <button type="submit" class="btn btn-primary mt-2">Submit POST</button>
	</form>
    </div>	
    <div class="d-flex justify-content-center align-items-center">
    	<form name="uploadForm" method="POST" action="action_upload.php" enctype="multipart/form-data" >
	  <div class="form-group">
	    <label for="inputFile">File Input</label>
	    <input type="file" name="fileInput" class="form-control-file" id="inputFile">
	  </div>
	  <button type="submit" name="submit" class="btn btn-primary mt-2">Submit FILE</button>
    	</form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
