<?php
   if (($_FILES['fileInput']['name']!="")){
      $target_dir = "files/";
      $file = $_FILES['fileInput']['name'];
      $path = pathinfo($file);
      $filename = $path['filename'];
      $ext = $path['extension'];
      $temp_name = $_FILES['fileInput']['tmp_name'];
      $path_filename_ext = $target_dir.$filename.".".$ext;
 
      if (file_exists($path_filename_ext)) {
 	echo "Acest fisier deja exista!";
      } else {
        move_uploaded_file($temp_name,$path_filename_ext);
        echo "Fisierul a fost salvat cu succes.";
      }
   } else echo "Nu poti incarca ceva gol!";
?>
